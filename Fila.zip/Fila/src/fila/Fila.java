
package fila;


public class Fila {
    String tipo;
    int numero;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = "";
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = 0;
    }

    public Fila(String tipo, int numero) {
        this.tipo = tipo;
        this.numero = numero;
    }
     public Fila(){
      this.tipo = " ";
      this.numero = 0;
  }
     public Fila(String tipo){
     
     }

    @Override
    public String toString() {
        return "Fila{" + "tipo=" + tipo + ", numero=" + numero + '}';
    }
   
    
    
}
